import sys
import pygame as pg, math
from pygame.locals import *
from random import choice  # for generating the random secret number

# Initialize Pygame
pg.init()
fps = 60
clock = pg.time.Clock()

# Colors
WHITE = (255, 255, 255)
BLUE = (103, 190, 217)
GREEN = (38, 62, 6)

# Window
width, height = 490, 500
screen = pg.display.set_mode((width, height))
font = pg.font.Font('SourGummy-VariableFont_wdth,wght.ttf', 30)  # Path to .ttf file and size
intro_text = font.render(">> Press SPACE to begin <<", True, WHITE)  # White text for intro

# Scale images
def scale_image(image, scale):
    return pg.transform.smoothscale(image, (image.get_width() // scale, image.get_height() // scale))

# Load images
def load_image(image, scale):
    return scale_image(pg.image.load(image).convert_alpha(), scale)

# Get image rect
def rect(image, w_scale, h_scale):
    return image.get_rect(center=(width // w_scale, height // h_scale))

# Images
bg = pg.image.load('bg.PNG')
logo = load_image("logo__1.png", 2)
bull_img = load_image('bull.png', 3)
cow_img = load_image('cow2.png', 3)
original_logo = logo

# Center images
logo_rect = rect(logo, 2, 3)
bull_rect = rect(bull_img, 6, 4.5)
cow_rect = rect(cow_img, 1.2, 2)

# Time counter for animation
t = 0

# Game state
current_screen = "menu"  # Possible values: "menu", "game"

def win(message):
    screen.blit(message, ())

def get_number():
    available_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    secret_number = []

    for i in range(4):
        choice_num = choice(available_numbers)
        secret_number.append(choice_num)
        available_numbers.remove(choice_num)

    return secret_number

def check_guess(guess, number):
    bulls = 0
    cows = 0

    for i in range(4):
        if guess[i] in number:
            if guess[i] == number[i]:
                bulls += 1
            else:
                cows += 1

    return bulls, cows

def play(bull_img, cow_img):
    secret_number = get_number()
    attempts = 0
    input_active = True
    prev_guess = ""
    guess = ""
    allowed_chars = "0123456789"
    win = False
    bulls = None
    cows = None
    bull_img = scale_image(bull_img, 2.5)
    cow_img = pg.transform.flip(scale_image(cow_img, 2.5), True, False) # Flip image horizontally

    bull_rect = rect(bull_img, 8, 11)
    cow_rect = rect(cow_img, 2.5, 11)

    while not win:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()


            if event.type == pg.KEYDOWN:
                if event.key == pg.K_RETURN:
                    prev_guess = font.render(f"Previous guess: {guess}", True, GREEN)
                    input_active = False  # Stop accepting input

                    if guess == ''.join(secret_number):
                        print(f"You guessed correctly!\nIt took you {attempts} attempts.")
                        win = True
                    else:
                        attempts += 1
                        bulls, cows = check_guess(guess, secret_number)
                        guess = ""

                    allowed_chars = "0123456789"

                elif event.key == pg.K_BACKSPACE:
                    allowed_chars = allowed_chars + guess[:-1]
                    guess = guess[:-1]  # Remove last character

                else:
                    # Add typed character (ignore non-printable keys)
                    if event.unicode in allowed_chars and len(guess) < 4:
                        guess += event.unicode
                        allowed_chars = allowed_chars.replace(guess, '')  # Remove used characters from allowed ones

        # This is where the game screen would be rendered during the play state
        screen.blit(bg, (0, 0))
        guess_text = font.render(f"Your guess: {guess}", True, WHITE)

        if prev_guess != "":
            screen.blit(prev_guess, (width // 2 - prev_guess.get_width() // 2, 310))

        screen.blit(guess_text, (width // 2 - guess_text.get_width() // 2, 380))
        screen.blit(bull_img, bull_rect)
        screen.blit(cow_img, cow_rect)

        if bulls != None and cows != None:
            screen.blit(font.render(f"{bulls}", True, BLUE), (110, 25))
            screen.blit(font.render(f"{cows}", True, BLUE), (245, 25))
        pg.display.flip()
        clock.tick(fps)

    

# Main loop
while True:
    for event in pg.event.get():
        if event.type == QUIT:
            pg.quit()
            sys.exit()

    # Handle screen transitions
    if current_screen == "menu":
        # Show the intro screen and wait for user input
        screen.blit(bg, (0, 0))  # Background image

        # Animation for logo breathing effect
        t += 0.05
        scale = 1 + math.sin(t) * 0.05  # Smooth breathing/undulating effect

        new_size = (
            int(original_logo.get_width() * scale),
            int(original_logo.get_height() * scale)
        )

        logo = pg.transform.smoothscale(original_logo, new_size)
        animated_rect = logo.get_rect(center=logo_rect.center)

        angle = math.sin(t) * 3   # rotates between -3° and +3°
        rotated = pg.transform.rotozoom(bull_img, angle, 1)
        rotated2 = pg.transform.rotozoom(cow_img, angle, 1)

        # Draw everything on the menu screen
        screen.blit(rotated, bull_rect)
        screen.blit(rotated2, cow_rect)
        screen.blit(logo, animated_rect)
        screen.blit(intro_text, (50, 380))  # Render intro text at the bottom

        # Check if spacebar is pressed to transition to the game screen
        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_SPACE:
                    current_screen = "game"

    elif current_screen == "game":
        # Transition to the game logic (play the number-guessing game)
        play(bull_img, cow_img) 
        current_screen = "menu" # After the game ends, go to the win screen


    pg.display.flip()
    clock.tick(fps)
